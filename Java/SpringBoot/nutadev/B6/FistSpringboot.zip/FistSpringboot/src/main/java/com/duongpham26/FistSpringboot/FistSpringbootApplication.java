package com.duongpham26.FistSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FistSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FistSpringbootApplication.class, args);
	}

}
